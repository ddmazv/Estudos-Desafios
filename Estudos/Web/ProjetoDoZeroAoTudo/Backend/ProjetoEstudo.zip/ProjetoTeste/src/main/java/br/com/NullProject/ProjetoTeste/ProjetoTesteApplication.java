package br.com.NullProject.ProjetoTeste;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoTesteApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoTesteApplication.class, args);
	}

}
