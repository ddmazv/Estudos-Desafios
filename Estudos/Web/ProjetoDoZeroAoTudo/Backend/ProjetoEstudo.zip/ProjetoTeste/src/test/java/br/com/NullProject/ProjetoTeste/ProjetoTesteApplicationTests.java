package br.com.NullProject.ProjetoTeste;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoTesteApplicationTests {

	@Test
	void contextLoads() {
	}

}
